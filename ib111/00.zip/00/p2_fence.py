from ib111 import week_00  # noqa
from turtle import forward, backward, left, right, done, speed


# Napište program, který nakreslí „plot“ o délce ‹length› pixelů,
# složený z prken (obdélníků) o šířce ‹plank_width› a výšce
# ‹plank_height›. Přesahuje-li poslední prkno požadovanou délku
# plotu, ořežte jej tak, aby měl plot přesně délku ‹length›.
# Zamyslete se nad rozdělením vykreslování do několika samostatných
# procedur. Při kreslení se vám také může hodit while cyklus.


def fence(length, plank_width, plank_height):
    pass


def main():
    speed(4)
    fence(140, 40, 100)
    done()


if __name__ == "__main__":
    main()
