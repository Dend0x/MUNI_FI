from ib111 import week_00  # noqa
from turtle import forward, left, done, penup, pendown, speed, delay
from math import pi


# Napište proceduru, která bude kreslit soustředné kružnice, a to
# tak, že první má poloměr ‹radius› a zbytek je rovnoměrně rozložen
# tak, aby bylo kružnic celkem ‹count›.

def target(radius, count):
    pass


def main():
    speed(0)
    delay(0)
    target(100, 4)
    done()


if __name__ == "__main__":
    main()
