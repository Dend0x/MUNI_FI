from ib111 import week_00  # noqa
from turtle import forward, backward, left, right, done, \
    penup, pendown, speed


# Napište proceduru, která nakreslí „tunel“ – sekvenci soustředných
# čtverců, kde vnější má stranu délky ‹size› a každý další je
# o ‹step› jednotek menší.

def tunnel(size, step):
    pass


def main():
    speed(5)
    tunnel(150, 30)
    done()


if __name__ == "__main__":
    main()
